class LeftRightPair:
    def __init__(self, left, right):
        self.left = left;
        self.right = right;

class XYPair:
    def __init__(self, x, y):
        self.x = x
        self.y = y
