#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector<double> a;
    cout << sizeof(a);
    return 0;
}
